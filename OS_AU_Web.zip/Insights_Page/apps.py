from django.apps import AppConfig


class InsightsPageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Insights_Page'
