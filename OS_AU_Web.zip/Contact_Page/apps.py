from django.apps import AppConfig


class ContactPageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Contact_Page'
