from django.apps import AppConfig


class WebsiteSettingsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Website_Settings'
